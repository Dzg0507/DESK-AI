package com.example.ui.dialogs

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.InstallMobile
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import com.example.BuildConfig
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldConnected
import com.example.ui.theme.RoseError
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

enum class UpdateState {
    IDLE,
    CHECKING,
    DOWNLOADING,
    READY_TO_INSTALL,
    PERMISSION_REQUIRED,
    ERROR
}

@Composable
fun AppUpdaterDialog(
    serverBaseUrl: String,
    authToken: String = "",
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val defaultUpdateUrl = remember(serverBaseUrl) {
        val base = serverBaseUrl.trimEnd('/')
        if (base.isNotBlank()) "$base/DeskAI.apk" else "http://10.0.2.2:8080/DeskAI.apk"
    }

    var downloadUrl by remember { mutableStateOf(defaultUpdateUrl) }
    var updateState by remember { mutableStateOf(UpdateState.IDLE) }
    var statusMessage by remember { mutableStateOf("Ready to check for updates.") }
    var progress by remember { mutableFloatStateOf(0f) }
    var downloadedBytes by remember { mutableLongStateOf(0L) }
    var totalBytes by remember { mutableLongStateOf(0L) }
    var downloadedFile by remember { mutableStateOf<File?>(null) }
    var showCustomUrl by remember { mutableStateOf(false) }

    fun checkAndDownloadApk(targetUrl: String) {
        scope.launch {
            updateState = UpdateState.DOWNLOADING
            progress = 0f
            downloadedBytes = 0L
            totalBytes = 0L
            statusMessage = "Connecting to update server..."

            withContext(Dispatchers.IO) {
                try {
                    val client = OkHttpClient.Builder()
                        .connectTimeout(15, TimeUnit.SECONDS)
                        .readTimeout(60, TimeUnit.SECONDS)
                        .build()

                    val candidateUrls = mutableListOf(targetUrl)
                    val cleanBase = serverBaseUrl.trimEnd('/')
                    if (cleanBase.isNotBlank()) {
                        if (!candidateUrls.contains("$cleanBase/DeskAI.apk")) candidateUrls.add("$cleanBase/DeskAI.apk")
                        if (!candidateUrls.contains("$cleanBase/static/DeskAI.apk")) candidateUrls.add("$cleanBase/static/DeskAI.apk")
                        if (!candidateUrls.contains("$cleanBase/DeskAI-update.apk")) candidateUrls.add("$cleanBase/DeskAI-update.apk")
                    }
                    val cloudFallback = "https://ais-dev-q3rsvd2z4tkbdyypw443cl-695475584713.us-east1.run.app/DeskAI.apk"
                    if (!candidateUrls.contains(cloudFallback)) candidateUrls.add(cloudFallback)

                    var successfulResponse: okhttp3.Response? = null
                    var usedUrl = targetUrl

                    for (url in candidateUrls) {
                        try {
                            withContext(Dispatchers.Main) {
                                statusMessage = "Attempting: ${url.take(40)}..."
                            }
                            val reqBuilder = Request.Builder().url(url)
                            if (authToken.isNotBlank()) {
                                reqBuilder.addHeader("X-HUD-Token", authToken.trim())
                                reqBuilder.addHeader("Authorization", "Bearer ${authToken.trim()}")
                            }
                            val resp = client.newCall(reqBuilder.build()).execute()
                            if (resp.isSuccessful && resp.body != null) {
                                successfulResponse = resp
                                usedUrl = url
                                break
                            } else {
                                resp.close()
                            }
                        } catch (_: Exception) {
                            // Try next candidate
                        }
                    }

                    if (successfulResponse == null) {
                        withContext(Dispatchers.Main) {
                            updateState = UpdateState.ERROR
                            statusMessage = "Update not found (HTTP 404). Place DeskAI.apk in your computer agent folder or use Cloud fallback."
                        }
                        return@withContext
                    }

                    val body = successfulResponse.body
                    if (body == null) {
                        withContext(Dispatchers.Main) {
                            updateState = UpdateState.ERROR
                            statusMessage = "Empty response received from update server."
                        }
                        return@withContext
                    }

                    val length = body.contentLength()
                    withContext(Dispatchers.Main) {
                        totalBytes = length
                        statusMessage = if (length > 0) {
                            "Downloading update (${String.format("%.1f", length / (1024.0 * 1024.0))} MB)..."
                        } else {
                            "Downloading update..."
                        }
                    }

                    val apkDir = File(context.getExternalFilesDir(null) ?: context.filesDir, "apks").apply { mkdirs() }
                    val apkFile = File(apkDir, "DeskAI-update.apk")
                    if (apkFile.exists()) apkFile.delete()

                    val inputStream = body.byteStream()
                    val outputStream = FileOutputStream(apkFile)
                    val buffer = ByteArray(8192)
                    var bytesRead: Int
                    var totalRead = 0L

                    while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                        outputStream.write(buffer, 0, bytesRead)
                        totalRead += bytesRead
                        if (length > 0) {
                            val currentProgress = totalRead.toFloat() / length
                            withContext(Dispatchers.Main) {
                                downloadedBytes = totalRead
                                progress = currentProgress
                            }
                        }
                    }

                    outputStream.flush()
                    outputStream.close()
                    inputStream.close()

                    if (totalRead < 1000000L) {
                        withContext(Dispatchers.Main) {
                            updateState = UpdateState.ERROR
                            statusMessage = "Download incomplete (${totalRead / 1024} KB). Please check your connection and retry."
                        }
                        return@withContext
                    }

                    withContext(Dispatchers.Main) {
                        downloadedFile = apkFile
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            if (!context.packageManager.canRequestPackageInstalls()) {
                                updateState = UpdateState.PERMISSION_REQUIRED
                                statusMessage = "Download complete! Android requires permission to install updates."
                            } else {
                                updateState = UpdateState.READY_TO_INSTALL
                                statusMessage = "Update downloaded (${String.format("%.1f", totalRead / (1024.0 * 1024.0))} MB). Ready to install!"
                                launchInstaller(context, apkFile)
                            }
                        } else {
                            updateState = UpdateState.READY_TO_INSTALL
                            statusMessage = "Update downloaded. Ready to install!"
                            launchInstaller(context, apkFile)
                        }
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        updateState = UpdateState.ERROR
                        statusMessage = "Download failed: ${e.localizedMessage ?: "Connection error"}"
                    }
                }
            }
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF0F172A))
                .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(16.dp))
                .padding(20.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.SystemUpdate,
                            contentDescription = "App Updates",
                            tint = ElectricCyan,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "In-App Updater",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color(0xFF94A3B8)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Current Version Info Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF1E293B))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Installed Version",
                                fontSize = 11.sp,
                                color = Color(0xFF94A3B8)
                            )
                            Text(
                                text = "DeskAI v${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(EmeraldConnected.copy(alpha = 0.15f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "ACTIVE",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldConnected
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Status Message Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            when (updateState) {
                                UpdateState.READY_TO_INSTALL -> EmeraldConnected.copy(alpha = 0.12f)
                                UpdateState.ERROR -> RoseError.copy(alpha = 0.12f)
                                else -> Color(0xFF111827)
                            }
                        )
                        .border(
                            1.dp,
                            when (updateState) {
                                UpdateState.READY_TO_INSTALL -> EmeraldConnected.copy(alpha = 0.4f)
                                UpdateState.ERROR -> RoseError.copy(alpha = 0.4f)
                                else -> Color(0xFF1F2937)
                            },
                            RoundedCornerShape(10.dp)
                        )
                        .padding(12.dp)
                ) {
                    Column {
                        Text(
                            text = statusMessage,
                            fontSize = 13.sp,
                            color = when (updateState) {
                                UpdateState.READY_TO_INSTALL -> EmeraldConnected
                                UpdateState.ERROR -> RoseError
                                else -> Color(0xFFE2E8F0)
                            },
                            lineHeight = 18.sp
                        )

                        if (updateState == UpdateState.DOWNLOADING) {
                            Spacer(modifier = Modifier.height(10.dp))
                            if (totalBytes > 0) {
                                LinearProgressIndicator(
                                    progress = { progress },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp)),
                                    color = ElectricCyan,
                                    trackColor = Color(0xFF1E293B)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${(progress * 100).toInt()}%",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = ElectricCyan,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = "${String.format("%.1f", downloadedBytes / (1024.0 * 1024.0))} / ${String.format("%.1f", totalBytes / (1024.0 * 1024.0))} MB",
                                        fontSize = 11.sp,
                                        color = Color(0xFF94A3B8),
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            } else {
                                LinearProgressIndicator(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp)),
                                    color = ElectricCyan,
                                    trackColor = Color(0xFF1E293B)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Source Selector Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val isLocalSelected = downloadUrl == defaultUpdateUrl
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isLocalSelected) ElectricCyan.copy(alpha = 0.2f) else Color(0xFF1E293B))
                            .border(1.dp, if (isLocalSelected) ElectricCyan else Color(0xFF334155), RoundedCornerShape(8.dp))
                            .clickable { downloadUrl = defaultUpdateUrl }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "🖥️ Computer Agent",
                            fontSize = 11.sp,
                            fontWeight = if (isLocalSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isLocalSelected) ElectricCyan else Color(0xFFCBD5E1)
                        )
                    }

                    val cloudUrl = "https://ais-dev-q3rsvd2z4tkbdyypw443cl-695475584713.us-east1.run.app/DeskAI.apk"
                    val isCloudSelected = downloadUrl == cloudUrl
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isCloudSelected) ElectricCyan.copy(alpha = 0.2f) else Color(0xFF1E293B))
                            .border(1.dp, if (isCloudSelected) ElectricCyan else Color(0xFF334155), RoundedCornerShape(8.dp))
                            .clickable { downloadUrl = cloudUrl }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "☁️ Cloud Build",
                            fontSize = 11.sp,
                            fontWeight = if (isCloudSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isCloudSelected) ElectricCyan else Color(0xFFCBD5E1)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Custom URL toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showCustomUrl = !showCustomUrl }
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (showCustomUrl) "▾ Update URL / Source" else "▸ Update URL / Source",
                        fontSize = 12.sp,
                        color = Color(0xFF94A3B8)
                    )
                    Text(
                        text = "Customize",
                        fontSize = 11.sp,
                        color = ElectricCyan
                    )
                }

                if (showCustomUrl) {
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = downloadUrl,
                        onValueChange = { downloadUrl = it },
                        label = { Text("APK Download URL", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricCyan,
                            unfocusedBorderColor = Color(0xFF334155),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Action Buttons
                when (updateState) {
                    UpdateState.DOWNLOADING -> {
                        Button(
                            onClick = { /* downloading */ },
                            enabled = false,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(disabledContainerColor = Color(0xFF1E293B))
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = ElectricCyan,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Downloading Update...", color = Color(0xFF94A3B8))
                        }
                    }
                    UpdateState.PERMISSION_REQUIRED -> {
                        Button(
                            onClick = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    val intent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).apply {
                                        data = Uri.parse("package:${context.packageName}")
                                    }
                                    context.startActivity(intent)
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan)
                        ) {
                            Icon(imageVector = Icons.Default.InstallMobile, contentDescription = null, tint = Color.Black)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Grant Install Permission", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                        if (downloadedFile != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = { launchInstaller(context, downloadedFile!!) },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldConnected)
                            ) {
                                Text("Try Installing Now", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    UpdateState.READY_TO_INSTALL -> {
                        Button(
                            onClick = {
                                downloadedFile?.let { launchInstaller(context, it) }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldConnected)
                        ) {
                            Icon(imageVector = Icons.Default.InstallMobile, contentDescription = null, tint = Color.Black)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Install Update Now", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                    else -> {
                        // IDLE or ERROR
                        Button(
                            onClick = { checkAndDownloadApk(downloadUrl) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Download,
                                contentDescription = null,
                                tint = Color.Black
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Download & Install Update",
                                color = Color.Black,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun launchInstaller(context: Context, apkFile: File) {
    try {
        if (!apkFile.exists() || apkFile.length() < 1000000L) {
            Toast.makeText(context, "Error: APK file incomplete (${apkFile.length()} bytes)", Toast.LENGTH_LONG).show()
            return
        }

        val apkUri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            apkFile
        )
        val installIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(apkUri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }

        // Explicitly grant read permission to package installer components
        val resolveList = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.packageManager.queryIntentActivities(installIntent, PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_DEFAULT_ONLY.toLong()))
        } else {
            @Suppress("DEPRECATION")
            context.packageManager.queryIntentActivities(installIntent, PackageManager.MATCH_DEFAULT_ONLY)
        }
        for (resolveInfo in resolveList) {
            val pkg = resolveInfo.activityInfo.packageName
            context.grantUriPermission(pkg, apkUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        context.startActivity(installIntent)
    } catch (e: Exception) {
        Toast.makeText(context, "Could not open installer: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
    }
}
